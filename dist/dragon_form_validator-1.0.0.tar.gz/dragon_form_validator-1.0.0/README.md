## Description

The dragon form validator module is the best way to validate your form elements and is suitable for every web app framework like a flask, Django, and other uses. It will check the form values, whether it's fit your form or not.

## Highlights about Dragon Form Validator:

tested 200+ fake emails - It filters out easily
gives you excellent validation results without fail
game changer for your forms
computer understand format in boolean - 0 or 1

## copyright & License

dragon form validator | Copyright @ Suresh P | MIT